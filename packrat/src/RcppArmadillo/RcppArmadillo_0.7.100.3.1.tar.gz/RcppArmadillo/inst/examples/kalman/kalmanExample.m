function x = kalmanExample
  load pos.txt;			# renamed here
  x = kalmanM(pos);
end