cellProp01 = cellProperties( border.color = "gray", border.width = 2 )
cellProp02 = cellProperties(border.left.width = 0, border.right.width = 0
  , border.bottom.width = 2, border.top.width = 0
  , padding.bottom = 2, padding.top = 2
  , padding.left = 2, padding.right = 2 )
