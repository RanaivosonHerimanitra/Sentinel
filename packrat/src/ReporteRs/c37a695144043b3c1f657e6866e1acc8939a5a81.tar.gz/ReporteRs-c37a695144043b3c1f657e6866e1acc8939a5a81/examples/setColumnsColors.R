MyFTable = setColumnsColors( MyFTable, j=3:4, colors = "red" )
