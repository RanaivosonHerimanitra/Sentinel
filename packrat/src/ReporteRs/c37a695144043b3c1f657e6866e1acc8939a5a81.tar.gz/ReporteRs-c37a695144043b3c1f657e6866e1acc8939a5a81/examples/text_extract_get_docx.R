doc = docx( title = "My example", template = file.path(
  system.file(package = "ReporteRs"), "templates/bookmark_example.docx") )
