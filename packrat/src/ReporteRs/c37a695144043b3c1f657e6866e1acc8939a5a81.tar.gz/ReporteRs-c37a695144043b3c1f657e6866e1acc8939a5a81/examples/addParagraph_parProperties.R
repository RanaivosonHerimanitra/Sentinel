
# Add my.pars into the document doc
doc = addParagraph(doc, my.pars, 
  par.properties=parProperties(text.align="center", padding=24) )
