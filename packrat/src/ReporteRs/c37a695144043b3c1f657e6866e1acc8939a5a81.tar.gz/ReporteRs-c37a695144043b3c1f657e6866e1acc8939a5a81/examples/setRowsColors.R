MyFTable = setRowsColors( MyFTable, i=1:4, colors = "red" )
