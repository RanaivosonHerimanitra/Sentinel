list_bookmarks( doc )
