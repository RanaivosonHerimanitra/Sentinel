doc = addRScript(doc, text = "x = rnorm(100)
plot(density( x ) )" )
