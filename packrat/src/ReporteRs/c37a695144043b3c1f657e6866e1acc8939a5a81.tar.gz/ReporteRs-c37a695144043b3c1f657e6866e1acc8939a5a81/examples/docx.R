
options( "ReporteRs-fontsize" = 10 )
doc <- docx( )
