
# Add my.pars into the document doc
doc = addParagraph(doc, my.pars, stylename = "Normal" )
