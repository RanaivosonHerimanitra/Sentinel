
doc = addTitle( doc, "Title example 1" )
