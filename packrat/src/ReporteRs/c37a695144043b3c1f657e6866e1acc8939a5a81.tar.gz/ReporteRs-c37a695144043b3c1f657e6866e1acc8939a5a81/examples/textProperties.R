textProperties( font.size = 12 )

textProperties(color="red", 
  font.weight = "bold", 
  font.style = "italic",  
  underlined = TRUE
)

textProperties( shading.color = "red" )
