
doc = addTitle( doc, "Title example 2" )
