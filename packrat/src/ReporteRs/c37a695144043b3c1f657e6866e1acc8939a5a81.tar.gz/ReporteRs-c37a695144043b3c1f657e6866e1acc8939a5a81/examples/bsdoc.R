
options( "ReporteRs-fontsize" = 11 )
doc = bsdoc( )
