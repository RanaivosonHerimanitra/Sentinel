
doc = addTitle( doc, "Title example 4", level = 1 )
