## example with characters
headerRow = FlexRow( c("Column 1", "Column 2")
  , cell.properties = cellProperties(background.color="#527578") )
