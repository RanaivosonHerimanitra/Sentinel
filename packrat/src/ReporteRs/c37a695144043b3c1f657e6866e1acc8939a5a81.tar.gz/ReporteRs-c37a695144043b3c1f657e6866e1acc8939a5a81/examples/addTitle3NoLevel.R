
doc = addTitle( doc, "Title example 3" )
