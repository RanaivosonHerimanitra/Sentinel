doc = addTitle( doc, 'Title 1', level = 1 )

doc = addTitle( doc, 'Title 2', level = 1 )

doc = addTitle( doc, 'Title 3', level = 1 )

doc = addTitle( doc, 'Title A', level = 2 )

doc = addTitle( doc, 'Title B', level = 2 )

doc = addTOC( doc )
