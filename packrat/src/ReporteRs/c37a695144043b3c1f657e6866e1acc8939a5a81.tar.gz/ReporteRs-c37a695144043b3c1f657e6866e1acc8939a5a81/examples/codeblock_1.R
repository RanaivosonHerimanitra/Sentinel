cb_example = CodeBlock( text = "ls -a\nwhich -a ls" )
