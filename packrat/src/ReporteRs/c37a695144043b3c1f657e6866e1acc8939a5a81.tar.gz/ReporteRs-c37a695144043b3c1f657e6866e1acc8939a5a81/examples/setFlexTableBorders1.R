MyFTable = setFlexTableBorders( MyFTable, 
  inner.vertical = borderProperties( style = "dashed" ), 
  inner.horizontal = borderProperties( style = "dashed" ), 
  outer.vertical = borderProperties( width = 2 ), 
  outer.horizontal = borderProperties( width = 2 ) )
