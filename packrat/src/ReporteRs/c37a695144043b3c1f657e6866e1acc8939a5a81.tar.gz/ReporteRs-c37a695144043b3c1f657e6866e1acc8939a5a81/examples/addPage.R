
# add a page with title "page example"
doc = addPage( doc, title = "page example" )
