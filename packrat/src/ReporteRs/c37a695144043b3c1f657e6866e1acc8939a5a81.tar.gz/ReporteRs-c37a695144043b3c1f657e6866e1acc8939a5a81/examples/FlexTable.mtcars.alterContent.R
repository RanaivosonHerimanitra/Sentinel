# add text to elements of the column cyl
MyFTable[, "cyl", text.properties = textProperties( 
  vertical.align="superscript", font.size = 9) ] = " miles/gallon"
