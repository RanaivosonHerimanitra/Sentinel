
options( "ReporteRs-fontsize" = 24 )
doc = pptx( title = "title" )
