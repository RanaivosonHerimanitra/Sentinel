
writeDoc( doc, file = doc.filename )
