# Zebra striped table
MyFTable = setZebraStyle( MyFTable, odd = "#8A949B", even = "#FAFAFA" )
