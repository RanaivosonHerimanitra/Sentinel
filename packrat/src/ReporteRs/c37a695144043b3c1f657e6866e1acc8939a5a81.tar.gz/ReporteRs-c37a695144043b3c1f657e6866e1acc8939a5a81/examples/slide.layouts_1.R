# get layouts names
layouts = slide.layouts(doc)
layouts
