## example with FlexCell
headerRow = FlexRow()
headerRow[1] = FlexCell( "Column 1"
  , cell.properties = cellProperties(background.color="#527578")  )
headerRow[2] = FlexCell( "Column 2"
  , cell.properties = cellProperties(background.color="#527578")  )
