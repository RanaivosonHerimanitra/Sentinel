mydd = DropDownMenu( label = "My menu" )
mydd = addLinkItem( mydd, 
	label = "GitHub", "http://github.com/", active = TRUE)
mydd = addLinkItem( mydd, separator.after = TRUE)
mydd = addLinkItem( mydd, 
	label = "Wikipedia", "http://www.wikipedia.fr")
