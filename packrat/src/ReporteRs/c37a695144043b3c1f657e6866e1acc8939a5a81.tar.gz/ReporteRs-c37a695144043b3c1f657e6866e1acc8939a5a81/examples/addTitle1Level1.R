
doc = addTitle( doc, "Title example 1", level = 1 )
