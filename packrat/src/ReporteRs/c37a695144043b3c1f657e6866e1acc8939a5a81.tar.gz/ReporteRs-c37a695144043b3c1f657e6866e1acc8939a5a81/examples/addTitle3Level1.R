
doc = addTitle( doc, "Title example 3", level = 1 )
