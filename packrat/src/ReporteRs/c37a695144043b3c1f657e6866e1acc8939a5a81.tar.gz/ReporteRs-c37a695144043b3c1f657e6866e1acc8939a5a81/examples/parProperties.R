parProperties( text.align = "center", padding = 5)

parProperties( text.align = "center", 
  padding.top = 5,
  padding.bottom = 0,
  padding.left = 2,
  padding.right = 0
)

parProperties( list.style = "ordered", level = 2)

parProperties( list.style = "unordered", level = 2)
