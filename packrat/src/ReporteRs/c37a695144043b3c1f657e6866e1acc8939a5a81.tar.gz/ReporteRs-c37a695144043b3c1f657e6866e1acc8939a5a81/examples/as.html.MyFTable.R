
# get HTML of the FlexTable
as.html( MyFTable )
