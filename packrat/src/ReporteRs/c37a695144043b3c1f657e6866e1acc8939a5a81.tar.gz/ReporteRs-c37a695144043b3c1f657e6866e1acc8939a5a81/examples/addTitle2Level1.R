
doc = addTitle( doc, "Title example 2", level = 1 )
