
# add a slide with layout "Title and Content"
doc = addSlide( doc, slide.layout = "Title and Content" )
