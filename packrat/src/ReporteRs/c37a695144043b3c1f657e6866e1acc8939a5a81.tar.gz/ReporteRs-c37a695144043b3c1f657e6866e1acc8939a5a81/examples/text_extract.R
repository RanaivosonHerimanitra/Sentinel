text_extract( doc )
text_extract( doc, header = FALSE, footer = FALSE )
text_extract( doc, bookmark = "author" )
