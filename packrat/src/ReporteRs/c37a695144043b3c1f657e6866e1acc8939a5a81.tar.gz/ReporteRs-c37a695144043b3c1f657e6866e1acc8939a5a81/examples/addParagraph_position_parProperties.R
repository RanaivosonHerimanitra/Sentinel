
# Add my.pars into the document doc
doc = addParagraph(doc, my.pars, offx = 3, offy = 3, 
  width = 2, height = 0.5,
  par.properties=parProperties(text.align="center", padding=0) )
