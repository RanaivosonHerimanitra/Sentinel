
# Add "Hello World" into the document doc
doc = addParagraph(doc, "Hello Word", stylename = "Normal" )
