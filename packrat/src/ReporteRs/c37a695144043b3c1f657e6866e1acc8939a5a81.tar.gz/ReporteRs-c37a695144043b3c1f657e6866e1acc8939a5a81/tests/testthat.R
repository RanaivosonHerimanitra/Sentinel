library(testthat)
library(ReporteRs)

test_check("ReporteRs")
