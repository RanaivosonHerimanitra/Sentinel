map1b = Leaflet$new()
map1b$setView(c(45.5236, -122.675), zoom = 14)
map1b$tileLayer(provider = 'MapQuestOpen.OSM')
map1b