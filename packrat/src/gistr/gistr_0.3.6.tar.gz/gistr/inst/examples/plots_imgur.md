

## Scatter plot 


```r
plot(mpg ~ cyl, data=mtcars)
```

![plot of chunk unnamed-chunk-2](http://i.imgur.com/bDPhAPd.png) 

## Bar plot


```r
barplot(VADeaths)
```

![plot of chunk unnamed-chunk-3](http://i.imgur.com/DXeQ2yw.png) 

## Histogram


```r
hist(iris$Petal.Length)
```

![plot of chunk unnamed-chunk-4](http://i.imgur.com/RYXt7Lj.png) 
