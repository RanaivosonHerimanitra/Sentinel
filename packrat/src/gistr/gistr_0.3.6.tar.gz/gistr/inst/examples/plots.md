

## Scatter plot 


```r
plot(mpg ~ cyl, data=mtcars)
```

![plot of chunk unnamed-chunk-2](http://i.imgur.com/mSbJ1PF.png) 

## Bar plot


```r
barplot(VADeaths)
```

![plot of chunk unnamed-chunk-3](http://i.imgur.com/cCZ5YH9.png) 

## Histogram


```r
hist(iris$Petal.Length)
```

![plot of chunk unnamed-chunk-4](http://i.imgur.com/fKdOi34.png) 
