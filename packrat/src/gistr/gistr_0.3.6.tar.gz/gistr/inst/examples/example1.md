I shall generate random numbers.

    x <- rnorm(1000)

And I shall summarize them.

    summary(x)

    ##      Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
    ## -3.188000 -0.680700  0.009575 -0.013100  0.657200  3.001000
