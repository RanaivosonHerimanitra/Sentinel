#' ---
#' output: md_document
#' ---

#' head of mtcars
head(mtcars)

#' summarise data
iris[ iris$Sepal.Length > 7, ]
