#include <Rcpp.h>

using namespace Rcpp;
class empty_body_text
{
public:
  static std::string p_tag();
  static std::string x_tag();
  static std::string wps_tag();
};
