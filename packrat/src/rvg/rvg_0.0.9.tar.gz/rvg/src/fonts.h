
bool is_bold(int face);
bool is_italic(int face);
std::string fontname(const char* family_, int face,
   std::string serif_, std::string sans_,
   std::string mono_, std::string symbol_);
