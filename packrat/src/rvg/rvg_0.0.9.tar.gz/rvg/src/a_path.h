#include <Rcpp.h>

using namespace Rcpp;
class a_path
{
public:
  static std::string a_tag(NumericVector, NumericVector, bool);
};
