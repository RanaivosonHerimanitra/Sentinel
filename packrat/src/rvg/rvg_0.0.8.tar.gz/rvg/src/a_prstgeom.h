#include <Rcpp.h>

using namespace Rcpp;
class a_prstgeom
{
public:
  static std::string a_tag(std::string);
};
