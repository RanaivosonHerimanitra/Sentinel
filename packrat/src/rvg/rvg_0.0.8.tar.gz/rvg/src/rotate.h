double translate_rotate_x(double x, double y, double rot, double h, double w, double hadj);
double translate_rotate_y(double x, double y, double rot, double h, double w, double hadj);
