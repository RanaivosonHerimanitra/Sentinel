#' @useDynLib gdtools
#' @importFrom Rcpp sourceCpp
#' @importFrom grDevices is.raster
NULL
